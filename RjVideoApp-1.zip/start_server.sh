#!/bin/bash
npm install
node server.js
